#importando a classe, da forma mais usual
import matplotlib.pyplot as plt
import numpy as np
from typing import Union, Tuple
import csv

class Perceptron:
    def __init__(self, max_it: int, alpha: float, X: Union[list, np.array], d: Union[list, np.array], activation_function=None):
        self.max_it = max_it
        self.alpha = alpha
        self.X = np.array(X)
        self.d = np.array(d)
        self.activate_function = activation_function if activation_function != None else self.step_function
        self.w = np.array([])
        self.b = np.array([])
        self.Erro= []
        self.fit()

    @classmethod
    def step_function(self, u: float) -> int:
        return 1 if u >= 0 else 0

    @classmethod
    def sigmoid_function(self, u: float) -> int:
        sigm = 1 / (1 + np.exp(-u, dtype=np.float64))
        return round(sigm*10000) / 10000.0 # 4 decimais

    def init_arr(self, size: int, value) -> np.array:
        b = []
        for i in range(size):
            b.append(value)
        return np.array(b)
    
    def f(self, u: np.array) -> np.array:
        for i, v in enumerate(u):
            u[i] = self.activate_function(v)
        return u

    def predict(self, x: Union[list, np.array]) -> np.array:
        return self.f( np.matmul(self.w, x) + self.b )

    def fit(self) -> Tuple[np.array, np.array]:
        w = self.init_arr(                  # pesos inicias 
            len(np.unique(self.d, axis=0)), # numero de neurionios 
            self.init_arr(len(self.X), 0)   # numero de pesos
        )
        b = self.init_arr(len(w), 0.1)      # bias inicais  (mesmo tamanho do que neuronio)
        
        # entrada transposta
        X_t = np.transpose(self.X)

        t = 0 # iteracao
        E = 1 # erro quadrarico
        while t < self.max_it and E > 0: # Enquanto estiver err não está ativado
            E = 0
            for i, xi in enumerate(X_t): # para cada entrada (coluna de self.X)
                # calcular o perceptron de saida 
                yi = self.f( np.matmul(w, xi) + b )

                # calcular  o erro de saida
                ei = self.d[i] - yi

                # atualizar o peso de cada perceptron
                new_w = []
                for i_percp, wi in enumerate(w): # atualizar cada perceptron (cada celula de peso)
                    new_w.append(w[i_percp] + self.alpha * ei[i_percp] * xi)
                w = np.array(new_w)

                # atualizar o bias
                b = b + self.alpha * ei

                # atualizar o error quadratico
                E = E + np.sum(ei * ei)
                
            t += 1
            self.Erro.append(E)
        self.w = w
        self.b = b
        return w,b

def doenca2output(doenca_name: str) -> np.array:
    return {
        'DH': [0, 0, 1],
        'SL': [0, 1, 0],
        'NO': [1, 0, 0],
    }[doenca_name]

def extract_input_and_label(data_list: Union[list, np.array]):
    X = []
    d = []
    for data_entry in data_list:
        if len(data_entry) <= 0:
            continue
        
        parsed_data = []
        for feature in data_entry[0:-1]:
            parsed_data.append(float(feature))
            
        X.append(parsed_data)
        d.append(doenca2output(data_entry[-1]))
    X = np.transpose(X)
    return X,d

def clamp_sigmoid_output(y: np.array) -> np.array:
        max_y = float('-inf')
        for i, yi in enumerate(y):
            if yi > max_y:
                max_y = yi
        for i, yi in enumerate(y):
            if yi == max_y:
                y[i] = 1
            else:
                y[i] = 0
        return y

def get_doenca_types(y: np.array) -> np.array:
    doenca_types = []
    doenca_arr_position = (len(y[0]) - 1)

    for i in range(len(y)):
        has_element = False
        for j in range(len(doenca_types)):
            if len(y[i]) > 0 and y[i][doenca_arr_position] == doenca_types[j]:
                has_element = True
                break
        if len(y[i]) > 0 and has_element == False:
            doenca_types.append(y[i][doenca_arr_position])
    return doenca_types

def order_elements(y: np.array, doenca_types: np.array) -> np.array:
    ordered_array = []
    total_elements = int((len(y) - 1)/len(doenca_types))
    for i in range(total_elements):
        ordered_array.append(y[i])
        ordered_array.append(y[i + total_elements])
        ordered_array.append(y[i + (total_elements * 2)])
    return ordered_array


if __name__ == '__main__':
    # open csv/coloque aqui o caminho da entrada.
    doenca_data_reader = csv.reader(open('C:\\Users\\Abdul Kevin Alexis\\Downloads\\Redes Neurais-Victor Lara\\Redes Neurais-Victor Lara\\column_3C.dat'), delimiter=' ')

    data_list = []
    for data_entry in doenca_data_reader:
       # print(f"{data_entry}")
        data_list.append(data_entry)

   
    doenca_types = get_doenca_types(data_list)
    new_data_list = order_elements(data_list, doenca_types)

    # divide fitting/test
    data_fit = []
    data_test = []
    max_fit_data_index = round(len(new_data_list) * 0.7)
    for i, value in enumerate(new_data_list):
        if i < max_fit_data_index:
            data_fit.append(value)
        else:
            data_test.append(value)
    #print(f"{data_fit}")
    # extract input and label
    X_fit, d_fit = extract_input_and_label(data_fit)
    
    X_test, d_test = extract_input_and_label(data_test)

   # print(f"{X_fit}")
   # print(f"{d_fit}")

    # Passo funcao de activacao
    # fit perceptron
    p_step = Perceptron(100, 0.1, X_fit, d_fit)
    
    # teste do trenamento
    correct_predictions = 0
    for i, x in enumerate(np.transpose(X_test)):
        prediction = p_step.predict(x)
        if (prediction == d_test[i]).all():
            correct_predictions += 1
    print(f"acuracia degrau: {correct_predictions/len(d_test)}")

    # #plotar grafico
    # x=np.arange(len(p_step.Erro))
    # y=p_step.Erro

    # plt.plot(x,y,'--k')
    # plt.show()
    # print(f"{x}")
    # print(f"{y}")

    # Funcao de ativacao sigmoid
    # fit perceptron
    p_sigmoid = Perceptron(100, 0.1, X_fit, d_fit, activation_function=Perceptron.sigmoid_function)
    
    # teste de treinamento
    correct_predictions = 0
    for i, x in enumerate(np.transpose(X_test)):
        prediction = p_sigmoid.predict(x)
        prediction = clamp_sigmoid_output(prediction)
        if (prediction == d_test[i]).all():
            correct_predictions += 1
    print(f"acuracia sigmoidal: {correct_predictions/len(d_test)}")
