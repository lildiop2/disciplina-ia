import matplotlib.pyplot as plt
from matplotlib.ticker import LinearLocator
import numpy as np
import math
import random


class Clonalg:
    def __init__(self, max_it, n1, n2, p, beta, limits, evaluation):
        self.max_it = max_it
        self.N = n1
        self.n1 = n1
        self.n2 = n2
        self.beta = beta
        self.p = p
        self.nc = int(beta * self.N)  # Number of clones to be generate for each antibody
        self.evaluation = evaluation
        self.limits = limits

        # initialize population
        random.seed()

        self.results = np.zeros((3, self.max_it)) # 3: max, min and average
        self.population = np.random.randint(limits[0], limits[1], size=(self.N, 2))

    def select(self, population, fitness):
        # if n1 is equal N, then no selection is required
        if self.N == self.n1:
            return population, fitness

        indexes = fitness.argsort()[-self.n1::][::-1]
        # select the n1 highest fitness
        return population[indexes], fitness[indexes]


    def select_clones(self, population, fitness):
        # multimodal: select the best clone for each antibody and generate new population
        for i in range(0, self.N, self.nc):
            best = np.argmax(fitness[i * self.nc : i * self.nc + self.nc])
            self.population[i] = population[best]

    def clone(self, antibodies, fitness):
        fitness_clones = np.zeros(len(antibodies) * self.nc)
        clones = []
        for i, antibody in enumerate(antibodies):
            for j in range(i * self.nc, i * self.nc + self.nc):
                clones.append(antibody)
                fitness_clones[j] = fitness[i]
            i += self.nc

        return clones, fitness_clones

    def normalize(self, d):
        dmax = np.amax(d)
        return np.apply_along_axis(lambda di: di/dmax, 0,d)

    def mutation(self, clones, fitness):
        for (i,clone) in enumerate(clones):
            alpha = np.exp(-self.p * fitness[i])
            pb = random.uniform(0, 1)
            if(pb > alpha):
                continue

            random.seed()

            delta = clones[i][0] * alpha * random.choice([0.01,1])
            clones[i][0] = math.fmod(clones[i][0] + delta, self.limits[1])
            delta = clones[i][1] * alpha * random.choice([0.01,1])
            clones[i][1] = math.fmod(clones[i][1] + delta, self.limits[1])
        return clones

    def replace(self):
        if self.n2 == 0:
            return self.population

    def clonalg_opt(self):
        t = 1
        while t < self.max_it:
            self.fitness = np.apply_along_axis(self.evaluation, 1, self.population)
            
            self.results[0][t] = np.amax(self.fitness)
            self.results[1][t] = np.amin(self.fitness)
            self.results[2][t] = np.average(self.fitness)

            population_select, fitness_select = self.select(self.population, self.fitness)

            clones, fitness_clones = self.clone(population_select, fitness_select)

            fitness_clones_normalized = self.normalize(fitness_clones)

            clones_mutated = self.mutation(clones, fitness_clones_normalized)

            fitness_clones = np.apply_along_axis(self.evaluation, 1, clones_mutated)

            self.select_clones(clones_mutated, fitness_clones)

            self.replace()
            t = t + 1

    def graph(self):
        X1=[]
        X2=[]
        F=[]
        for i in self.population:
            X1.append(i[0])
            X2.append(i[1])

        plt.xlim(0, 10)
        plt.ylim(0, 10)
        plt.grid()

        plt.plot(X1, X2 ,marker="o", color="red", linestyle="None")
        plt.savefig("Figure_Point.png")
        plt.show()


        #grafico
    def graphic(self):
        X1=[]
        X2=[]
        F=[]
        for i in self.population:
            X1.append(i[0])
            X2.append(i[1])

        [X1, X2] = np.meshgrid(X1, X2)
        F = np.sqrt(X1) * np.sin(X1) * np.sqrt(X2) * np.sin(X2)
    # Criando a figura e projeção em 3D
        fig = plt.figure()
        ax=fig.add_subplot(1, 2, 1,projection='3d')
        surf=ax.plot_surface(X1, X2, F, cmap='jet',linewidth=0, antialiased=False)
        ax.set_title('Alpine02') 
        ax.set_xlabel('X1') # Coluna 1
        ax.set_ylabel('X2') 
        ax.set_zlabel('F(X1,X2)')

                # Customize the z axis.
        #ax.set_xlim(-10, 10)
        #ax.set_ylim(-10, 10)
        #ax.set_zlim(-10, 10)
        #ax.zaxis.set_major_locator(LinearLocator(10))
        # A StrMethodFormatter is used automatically
        #ax.zaxis.set_major_formatter('{x:.02f}')

        # Add a color bar which maps values to colors.
        #fig.colorbar(surf, shrink=0.5, aspect=5)

        #===============
        # Second subplot
        #===============
        # set up the axes for the second plot
        ax = fig.add_subplot(1, 2, 2, projection='3d')

        # plot a 3D wireframe like in the example mplot3d/wire3d_demo
        
        ax.plot_wireframe(X1, X2, F, rstride=10, cstride=10)
        plt.savefig("Figure_1.png")
  
        plt.show()

    def result(self):
        b = self.fitness.argmax(axis=0)

        return (self.population[b], self.fitness[b])



def  alpine02(args):
    x1 = args[0]; x2 = args[1];
    y = (math.sqrt(x1)*math.sin(x1) ) * (math.sqrt(x2)*math.sin(x2))
    return y
    
clonalg = Clonalg(50, 50, 0, 5, 0.1, (0, 10), alpine02)
clonalg.clonalg_opt()
print(f'x1:{clonalg.result()[0][0]}, x2:{clonalg.result()[0][1]}, f(x1,x2):{clonalg.result()[1]}')
clonalg.graphic()
clonalg.graph()

