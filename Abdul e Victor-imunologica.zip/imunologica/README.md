# clonalg

## Descrição
Implementação do algoritmo CLONALG baseado no Sistema Imunológico, para resolução de um problema de otimização multimodal, que nesse caso é encontrar o mínimo global da função eggholder.

## Requisitos de instalação
Para executar o algoritmo é necessário instalar:

```
$ sudo apt-get install -y python
$ sudo apt-get install -y python-numpy
$ sudo apt-get install -y python-matplotlib
```
